<template>
  <div class="dashboard-container" />
</template>

<script>
export default {
  name: 'Dashboard',
  data() {
    return {
    }
  }
}
</script>
